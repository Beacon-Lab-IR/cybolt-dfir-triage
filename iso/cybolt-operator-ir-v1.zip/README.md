# Cybolt DFIR — Operator-Induced Incident Acquisition Pack

Version: 1.1.0
Repo: https://github.com/Beacon-Lab-IR/cybolt-dfir-triage
Author: Cybolt DFIR (Beacon-Lab-IR)

## What this is

Self-contained bundle to run KAPE against a Windows host with suspected
operator-induced software delay or anomalous user activity within a
specific time window.

The browser tends to mangle file extensions on `.bat` and `.txt`
downloads (e.g. saving `RUN-KAPE.bat` as `RUN-KAPE.txt`, or stripping
`.txt` from `targets-full.txt`). This ZIP sidesteps that — extract once,
all extensions preserved.

## Files in this ZIP

- `RUN-KAPE.bat` — wrapper that auto-detects KAPE install, validates
  dependencies, and launches KAPE with the extended target list.
- `targets-full.txt` — exhaustive KAPE targets list, including the two
  compound targets `KapeTriage` + `!SANS_Triage` at the top, plus all
  supplementary individual targets.

## Required (NOT in this ZIP — separate download)

- `kape.exe` (CLI) or `gkape.exe` (GUI) — from https://www.kroll.com/
- `Targets/`, `Compound/`, `Modules/` folders — from KAPE release zip

## Setup (Windows, all on USB, no C: stage)

1. Connect USB evidence drive (any letter D:, E:, F:, ...).
2. Create `D:\KAPE\` on the USB.
3. Copy `kape.exe` (or `gkape.exe`) and the `Targets\`, `Compound\`,
   `Modules\` folders from the KAPE release into `D:\KAPE\`.
4. Extract this ZIP into `D:\KAPE\` (overwrite if prompted).
5. Final layout on USB:
   ```
   D:\KAPE\
   ├── kape.exe
   ├── gkape.exe            (optional, for GUI)
   ├── RUN-KAPE.bat         (from this ZIP)
   ├── targets-full.txt     (from this ZIP)
   ├── Targets\
   ├── Compound\
   └── Modules\
   ```

## Run via CLI (recommended)

1. Open CMD as Administrator.
2. Run: `D:\KAPE\RUN-KAPE.bat D` (use whatever letter the USB is on).
3. Wait 30-90 minutes. Bundle appears at
   `D:\%COMPUTERNAME%-YYYYMMDD-HHMMSS\%COMPUTERNAME%-KAPE-YYYYMMDD-HHMMSS.zip`.

If the USB letter is not D, just pass it: `D:\KAPE\RUN-KAPE.bat E`.

## Run via GUI (gkape.exe)

1. Double-click `D:\KAPE\gkape.exe`.
2. Source: `C:\`  |  Target: `D:\` (or `D:\%HOSTNAME%-...\`).
3. **Targets tab**: Add `KapeTriage` AND `!SANS_Triage` (the `!` is part
   of the target name, don't strip it). Then click **Load from file**
   and pick `targets-full.txt` for the supplementary targets.
4. **Modules tab**: tick at minimum:
   - EvtxECmd (event logs)
   - MFTECmd ($MFT, $UsnJrnl)
   - PECmd (prefetch)
   - AmCacheParser (execution history)
   - RegistryExplorer (UserAssist, BAM, RecentDocs)
5. **Options**: enable **VSS**.
6. Click **Execute**.

## What gets acquired

Two compound targets + supplementary:

- **KapeTriage** (Eric Zimmerman's compound): BasicCollection + EventLogs
  + RegistryHives + Prefetch + AmCache + PowerShell logs + ScheduledTasks
  + Services + AppCompat + LNKFilesAndJumpLists + EvidenceOfExecution
  + $MFT + $LogFile + $UsnJrnl.
- **!SANS_Triage** (SANS FOR508 curated): Registry hives + Event Logs +
  Prefetch + SRUM + Scheduled Tasks + Services + WMI + BAM + AppCompat +
  LNK + JumpLists + UserAssist + Recycle Bin + network artifacts +
  $MFT + $LogFile + $UsnJrnl.
- **Supplementary** (from targets-full.txt): Defender, WER, CrashDumps,
  BAM, SRUM, RecentDocs, Thumbnails, UserAssist, RunKeys, JumpLists,
  Recycle, WordWheelQuery, Search, RoamingProfile, USB devices,
  RDP cache, WBEM, WebBrowsers (Chrome/Firefox/Edge), OutlookPST,
  OneDrive, Teams.
- KAPE deduplicates overlapping selections — no real waste from running
  both compounds.

## Time-range filtering

KAPE does NOT filter by time at acquisition — it acquires everything.
The filtering happens post-acquisition with EZTools:

| Artifact | Tool | Flag |
|---|---|---|
| EVTX | `EvtxECmd` | `-d "YYYY-MM-DD..YYYY-MM-DD"` |
| $MFT | `MFTECmd` | `--date "..."` |
| Prefetch | `PECmd` | `--date "..."` |
| AmCache | `AmCacheParser` | filter by `KeyLastWriteTimestamp` |
| JumpLists | `JLECmd` | `-d "..."` |
| Registry | `RegistryExplorer` | Timeline view / `LastWriteTime` |

## Order of volatility (mandatory)

1. **RAM first**: `winpmem_mini_x64_rc2.exe D:\%HOSTNAME%-...\memory.raw`
2. **Then KAPE**: `RUN-KAPE.bat D`

Without RAM, if the operator closed session / rebooted, you lose the only
evidence of the live state at the moment of the software delay.

## Chain of custody

After KAPE finishes:

```bat
certutil -hashfile D:\%COMPUTERNAME%-YYYYMMDD-HHMMSS\%COMPUTERNAME%-KAPE-YYYYMMDD-HHMMSS.zip SHA256
```

Record the hash in your case notes before disconnecting the USB.